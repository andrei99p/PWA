﻿namespace PWA.Components
{
    public enum FileStatus
    {
        Loaded,
        Uploading,
        Uploaded,
        Error
    }
}
